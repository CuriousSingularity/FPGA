/*
 * CEncoderFsm.cpp
 *
 *  Created on: 07.05.2014
 *      Author: Marc Maier
 */

#define TRACE

#include "../headers/CEncoderFsm.h"

// GCC
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>

// Application level
#include "../headers/BitmapImage.h"
#include "../headers/JpegImage.h"
#include "../headers/CoreHuffmanEncoder.h"
#include "../headers/GlobalSettings.h"
#include "../headers/CoreColorConversion.h"
#include "../headers/CoreMatrixConversion.h"
#include "../headers/CoreFourierTransformFPGA.h"

// Xilinx system
#include "xparameters.h"
#include "xsdps.h"
#include "xsdps_hw.h"
#include "xil_io.h"
#include "xil_types.h"
#include "xil_cache.h"

namespace JpegEncoder {

const char *CEncoderFsm::m_bmpFolderPath = "BMP";
const char *CEncoderFsm::m_jpgFolderPath = "JPG";

static const double c_CLOCK_TO_MILLISECONDS = XPAR_AXI_TIMER_0_CLOCK_FREQ_HZ / 1000;

// use 50 is push button 1 and 51 is push button 2
#define PUSH_BUTTON 	50
#define LED_OUTPUT		07
// direction zero is input
#define DIRECTION_IN 	0
#define DIRECTION_OUT 	1



CEncoderFsm::CEncoderFsm()
{
    m_bmpImage = 0;
    m_jpegImage = 0;

    m_state = ready;
}

CEncoderFsm::~CEncoderFsm()
{
	/* nothing to do */
}

void CEncoderFsm::collectSeconds(double *p_ModuleTime, double *p_EncodingTime)
{
   // Collected the time amount in seconds to prevent a timer overrun
   // The timer can count up to 14 seconds at maximum and then he stops
   // To prevent the time amount loss, we collect the seconds.
   double l_TimeInSeconds = XTmrCtr_GetValue(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID) / c_CLOCK_TO_MILLISECONDS;
   if (p_EncodingTime != NULL) (*p_EncodingTime) += l_TimeInSeconds;
   if (p_ModuleTime != NULL) (*p_ModuleTime) += l_TimeInSeconds;
   XTmrCtr_Reset(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID);
   XTmrCtr_Start(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID);
}

bool CEncoderFsm::startPushed()
{
	// Read push button. Returns 1 if button is pushed
	return !!XGpioPs_ReadPin(&m_Btn, PUSH_BUTTON);
}

bool CEncoderFsm::isBmp(const char *fname) const
{
	const char *c;
	bool ret = false;

	/* strings are zero terminated */
	if ((c = strrchr(fname, '.')) != NULL) {
		if (strlen(c) > 1) {
			if (strcmp(c++, "bmp") == 0
				|| strcmp(c, "BMP") == 0) {
				ret = true;
			} else {
				/* ignore non bmp file */
			}
		} else {
			/* not in 8.3 format, nothing behind the dot */
		}
	} else {
		/* not in 8.3 format, no dot at all */
	}
	return ret;
}

bool CEncoderFsm::initGpio(XGpioPs *Gpio, int Pin, int Direction)
{
	int res;
	XGpioPs_Config *GPIOConfigPtr = NULL;

	// GPIO Initilization
	GPIOConfigPtr = XGpioPs_LookupConfig(XPAR_PS7_GPIO_0_DEVICE_ID);

	if (GPIOConfigPtr != NULL) {
		res = XGpioPs_CfgInitialize(Gpio, GPIOConfigPtr, GPIOConfigPtr->BaseAddr);
		if (res == XST_SUCCESS) {
			// Set GPIO direction
			XGpioPs_SetDirectionPin(Gpio, Pin, Direction);
			return true;
		}
	}
	return false;
}

bool CEncoderFsm::initialize()
{
	bool ret = false;
	static bool mounted = false;
	FRESULT filres;

	DIR dir;
	FILINFO filinfo;

	std::cout << "INFO: Encoder FSM init started..." << std::endl;

	/* remove all old entries */
	m_bmpFilePaths.clear();

	/* initialize program timer */
	XTmrCtr_Initialize(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID);
	XTmrCtr_SetResetValue(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID,
			0x00000000);

	/* check if card is already mounted */
	if (! mounted) {
		/* Register volume work area, initialize device */
		if ((filres = f_mount(&m_fatfs,"0:",0)) == FR_OK)
			mounted = true;
	}

	if (mounted) {
		if (f_opendir(&dir, m_bmpFolderPath) == FR_OK) {
 			std::cout << "INFO: Collecting bmp files." << std::endl;

			while (1) {
				filres = f_readdir(&dir, &filinfo);

				if (filres != FR_OK) {
					std::cout << "ERROR: Could not read bmp dir." << std::endl;
				}

				/* skip all folders */
				if (filinfo.fattrib & AM_DIR) {
					continue;
				} else if (filinfo.fname[0] == 0) {
					/* end of dir or dir empty */
					ret = true;
					break;
				} else {
					/* check if file is bitmap, append to list */
					if (isBmp(filinfo.fname)) {
#ifdef TRACE
						std::cout << "TRACE: Adding bmp file: "
								  << filinfo.fname
								  << std::endl;
#endif
						m_bmpFilePaths.push_back(std::string("/") +
												 m_bmpFolderPath +
												 std::string("/") +
												 std::string(filinfo.fname));
					}
				}
			}
		} else {
			std::cout << "ERROR: Could not open bmp source dir." << std::endl;
		}
	} else {
		std::cout << "ERROR: Could not mount sd card." << std::endl;
	}
	return ret;
}

bool CEncoderFsm::createJpeg(const char *p_JpegFilename)
{
	bool l_Encoded = false;

	// First text line buffer of LCD Display
	char l_LcdFirstLine[50] = {0};
	// Second text line buffer of LCD Display
	char l_LcdSecondLine[50] = {0};

	// Timer variables to protocol the performance of each module
	double l_EncodingTime = 0;
	double l_ExtractionTime = 0;
	double l_FileTime = 0;
	double l_DctTime = 0;
	double l_ColorConversionTime = 0;
	double l_QuantizeTime = 0;
	double l_HuffmanTime = 0;
	// Reset timer and get start time amount for JPEG encoding
	collectSeconds(NULL, NULL);

	if (p_JpegFilename == NULL)
		return false;

	// Try to create the Jpeg file
	m_jpegImage = new JpegImage(p_JpegFilename,
			BitmapImage::getInfoHeader()->biBitCount,
			BitmapImage::getInfoHeader()->biHeight,
			BitmapImage::getInfoHeader()->biWidth);

	if (m_jpegImage->initialize(c_JPEG_QUALITY))
	{

		// Encoding buffers
		unsigned char l_PixelMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE][c_COLOR_AMOUNT];
		short l_YMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE];
		short l_CrMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE];
		short l_CbMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE];
		float l_Dct[c_MATRIX_SIZE][c_MATRIX_SIZE];
		short p_JpegPixel[c_NUMBER_OF_PIXELS];
		float l_resultMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE];

		float l_DctFPGA[c_MATRIX_SIZE][c_MATRIX_SIZE];

		xil_printf("INFO: Creating corresponding JPEG file: %s\r\n", p_JpegFilename);

		// Initialize the huffman encoder
		CoreHuffmanEncoder::reset();

		xil_printf("INFO: Converting Bitmap pixel to JPEG pixel values. \r\n");
		// Since we use 16x16 pixel blocks for subsampling,
		// but be aware that the amount of pixel might not be directly divideable through the matrix size
		float l_BitmapHeight = BitmapImage::getInfoHeader()->biHeight;
		float l_BitmapWidth = BitmapImage::getInfoHeader()->biWidth;
		int l_BitmapRows = (int) ceilf(l_BitmapHeight / (float) c_MATRIX_SIZE);
		int l_BitmapColumns = (int) ceilf(l_BitmapWidth / (float) c_MATRIX_SIZE);
		for (int l_Row = 0; l_Row < l_BitmapRows; l_Row++)
		{
			// Show current file progress status on LCD Panel
			sprintf(l_LcdSecondLine, "%s%d%s", "Status: ", (int) ((((float) l_Row + 1) / l_BitmapRows) * 100), "%");
			// FIXME: replace with oled, use uart for temp output
			//LcdControl::lcd_puts(l_LcdFirstLine, l_LcdSecondLine);
			std::cout << "OLED: " << l_LcdFirstLine << l_LcdSecondLine << std::endl;

			xil_printf("INFO: Converting image row: %d of %d \r\n", l_Row + 1, l_BitmapRows);
			for (int l_Column = 0; l_Column < l_BitmapColumns; l_Column++)
			{
				// Extract 16x16 pixel block
				collectSeconds(NULL, &l_EncodingTime);
				BitmapImage::extractPixelBlock(l_Row, l_Column, l_PixelMatrix);

				// Do color conversion and subsampling
				collectSeconds(&l_ExtractionTime, &l_EncodingTime);
				CoreColorConversion::convertRGB2YCbCr(l_PixelMatrix, l_YMatrix, l_CbMatrix, l_CrMatrix);
				collectSeconds(&l_ColorConversionTime, &l_EncodingTime);

				// Create the first Jpeg MCU AC + DC entry Y
				CoreFourierTransformFPGA::discreteCosinesTransformation(l_YMatrix, l_DctFPGA);

				collectSeconds(&l_DctTime, &l_EncodingTime);

				CoreMatrixConversion::quantize(l_DctFPGA, m_jpegImage->m_LuminanceQuantizationDivisor, p_JpegPixel);
				collectSeconds(&l_QuantizeTime, &l_EncodingTime);
				CoreHuffmanEncoder::encode(p_JpegPixel, 0);
				collectSeconds(&l_HuffmanTime, &l_EncodingTime);

				// Create blue chromance JPEG MCU AC + DC
				CoreFourierTransformFPGA::discreteCosinesTransformation(l_CbMatrix, l_DctFPGA);
				collectSeconds(&l_DctTime, &l_EncodingTime);


				CoreMatrixConversion::quantize(l_DctFPGA, m_jpegImage->m_ChrominanceQuantizationDivisor, p_JpegPixel);
				collectSeconds(&l_QuantizeTime, &l_EncodingTime);
				CoreHuffmanEncoder::encode(p_JpegPixel, 1);
				collectSeconds(&l_HuffmanTime, &l_EncodingTime);

				// Create red chromance JPEG MCU AC + DC
				CoreFourierTransformFPGA::discreteCosinesTransformation(l_CrMatrix, l_DctFPGA);
				collectSeconds(&l_DctTime, &l_EncodingTime);



				CoreMatrixConversion::quantize(l_DctFPGA, m_jpegImage->m_ChrominanceQuantizationDivisor, p_JpegPixel);
				collectSeconds(&l_QuantizeTime, &l_EncodingTime);
				CoreHuffmanEncoder::encode(p_JpegPixel, 2);
				collectSeconds(&l_HuffmanTime, &l_EncodingTime);

				// Write the created JPEG MCU block into the JPEG file
				m_jpegImage->writeData(CoreHuffmanEncoder::getEncodedData(), CoreHuffmanEncoder::getEncodedDataLength(), 0);
				collectSeconds(&l_FileTime, &l_EncodingTime);
			}
		}

		// Write end of JPEG file
		collectSeconds(NULL, &l_EncodingTime);
		CoreHuffmanEncoder::finish();
		collectSeconds(&l_HuffmanTime, &l_EncodingTime);
		m_jpegImage->writeData(CoreHuffmanEncoder::getEncodedData(), CoreHuffmanEncoder::getEncodedDataLength(), 0);
		m_jpegImage->writeFooter();
		m_jpegImage->finish();
		collectSeconds(&l_FileTime, &l_EncodingTime);

		// Print statistical information of encoding
		int m_jpgImageSize = m_jpegImage->getSize();
		int l_BitmapSize = BitmapImage::getSize();
		int l_Compression = (int) ((l_BitmapSize / m_jpgImageSize) * 100.0);
		xil_printf("INFO: JPEG Image conversion for: %s finished.\r\n", p_JpegFilename);
		xil_printf("INFO: JPEG File size: %d byte\r\n", m_jpegImage->getSize());
		xil_printf("INFO: JPEG compression rate: %d \r\n", l_Compression);

		l_Encoded = true;
	}
	else
	{
		xil_printf("ERROR: Unable to initialize JPEG image file: %s\r\n", p_JpegFilename);
	}

	// Free the allocated memory
	if (m_jpegImage != NULL)
	{
		delete m_jpegImage;
		m_jpegImage = NULL;
	}

	// Collected the time amount in seconds to prevent a timer overrun
	collectSeconds(NULL, &l_EncodingTime);
 	XTmrCtr_Stop(&s_XpsTimer, XPAR_TMRCTR_0_DEVICE_ID);

	// Show time amount for encoding
	xil_printf("INFO: JPEG image %s was encoded in: %dms\r\n", BitmapImage::getFilepath(), (int) l_EncodingTime);
	xil_printf("INFO: I/O time amount: %dms\r\n", (int) l_FileTime);
	xil_printf("INFO: Bitmap Block extraction time amount: %dms\r\n", (int) l_ExtractionTime);
	xil_printf("INFO: DCT time amount: %dms\r\n", (int) l_DctTime);
	xil_printf("INFO: Color Conversion time amount: %dms\r\n", (int) l_ColorConversionTime);
	xil_printf("INFO: Quantization time amount: %dms\r\n", (int) l_QuantizeTime);
	xil_printf("INFO: Huffman encoding time amount: %dms\r\n", (int) l_HuffmanTime);

	return l_Encoded;
}

std::string CEncoderFsm::createJpegPath(std::string bmpPath) const
{
	while (bmpPath.find("BMP") != std::string::npos) {
		 bmpPath.replace(bmpPath.find("BMP"), 3, "JPG");
	}
	return bmpPath;
}

bool CEncoderFsm::encode()
{
	bool res = true;

	// Check list of bmp files, if not empty process it one filer per iteration
	std::vector<std::string>::const_iterator i = m_bmpFilePaths.begin();

	for (; i != m_bmpFilePaths.end(); ++i) {
		if (BitmapImage::initialize((*i).c_str())) {
			std::cout << "INFO: Converting file " << *i << std::endl;
			res &= createJpeg(createJpegPath(*i).c_str());
		} else {
			std::cout << "ERROR: Could not initialize bmp object for" << std::endl;
		}
		BitmapImage::reset();
	}
	return res;
}

void CEncoderFsm::start()
{
	// TODO: add some OLED output to this class as before for the LCD

	// FIXME: gpio stuff sucks here
	bool res = true;
	res &= initGpio(&m_Btn, PUSH_BUTTON, DIRECTION_IN);
	res &= initGpio(&m_Led, LED_OUTPUT, DIRECTION_OUT);

	if (!res) {
		std::cout << "ERROR: GPIO init failed" << std::endl;
	}

	std::cout << "INFO: Push start button to start encoder" << std::endl;
    while (true) {
        switch (m_state) {
        case ready:
        	XGpioPs_WritePin(&m_Led, LED_OUTPUT, 1);
            if (startPushed()) {
            	XGpioPs_WritePin(&m_Led, LED_OUTPUT, 0);
                m_state = initializing;
            }
            break;
        case initializing:
            if (initialize()) {
            	std::cout << "INFO: Initialized!" << std::endl;
                m_state = encoding;
            } else {
                m_state = ready;
            }
            break;
        case encoding:
            encode();
            m_state = ready;
            break;
        default:
            assert(false);
        }
    }
}

} /* namespace JpegEncoder */

