/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#include "..\Headers\CoreMatrixConversion.h"
#include "math.h"

void CoreMatrixConversion::quantize( float p_PixelMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE], float p_QuantizationDivisor[c_MATRIX_SIZE][c_MATRIX_SIZE],
      short p_Pixel[c_NUMBER_OF_PIXELS] )
{
   // Loop through the given DCT Pixel Matrix in Zick-Zack
   // and quantize the DCT values
   short l_ZickZackIndex = 0, l_Row = 0, l_Column = 0;
   for ( l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++ )
   {
      for ( l_Column = 0; l_Column < c_MATRIX_SIZE; l_Column++ )
      {
         p_Pixel[c_ZIGZAG_MAP[l_ZickZackIndex]] = lroundf( p_PixelMatrix[l_Row][l_Column] * p_QuantizationDivisor[l_Row][l_Column] );
         l_ZickZackIndex++;
      }
   }
}
