/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */

// Xilinx System includes
#include <stdlib.h>
#include <string.h>
#include "ff.h"
#include "xparameters.h"
//#include "sysace_stdio.h"
//#include "xio.h"
#include "xil_printf.h"
#include <stdio.h>
#include "math.h"
// Application related includes
#include "..\Headers\BitmapImage.h"

// Maximal supported file size of a Bitmap image
// Increase if not enough
static const unsigned int c_BMP_MAXSIZE = 30 * 1024 * 1024; // -> currently 30MB maximum per bitmap, also check stack size in linker script for correct setting
// Supported Bitmap Bitcount
// 24 is the default Bit depth of bitmap files
// lower Bit depths are indexed
// Higher bit depths are unusual
static const int c_BMP_SUPPORT_DEPTH = 24;

// Defines if the bitmap file represented by this class instance could be loaded
static bool m_Initialized;
// System File Path of the bitmap file
static const char *m_FilePath;
// Memory handle for the file content
static FIL m_FileHandle;
// File Size
static unsigned int m_FileSize;
// Bytes read from the file
static unsigned int m_BytesRead;
// File Header Size
static int m_FileHeaderSize;
// Bitmap Row Padding byte (every pixel row must be dividable through 4)
static int m_Padding;
// Complete file content
static char m_FileContent[c_BMP_MAXSIZE];
// Bitmap File informations
static BITMAP_FILE_HEADER m_BmpFileHeader;
// Bitmap Header informations
static BITMAP_INFO_HEADER m_BmpInfoHeader;

void BitmapImage::reset()
{
	f_close(&m_FileHandle);

	// Reset class variables
	m_FileSize = 0;
	m_FilePath = NULL;
}

bool BitmapImage::initialize(const char *p_FilePath)
{
   // Initialize class member variables
   m_FilePath = p_FilePath;
   m_Initialized = false;
   m_FileSize = 0;
   m_FileHeaderSize = 0;
   memset(&m_BmpInfoHeader, 0x00, sizeof(m_BmpInfoHeader));
   memset(&m_BmpFileHeader, 0x00, sizeof(m_BmpFileHeader));
   memset(&m_FileHandle, 0x00, sizeof(m_FileHandle));
   memset(m_FileContent, 0x00, sizeof(m_FileContent));

   xil_printf("INFO: Initializing Bitmap image instance.\r\n");

   // Check if bitmap file was not already loaded
   if (m_Initialized == true)
   {
      // Bitmap already loaded
      xil_printf("ERROR: %s is already loaded\n\r", m_FilePath);
   }
   // Check for invalid path's
   else if (m_FilePath == NULL || strlen(m_FilePath) <= 0)
   {
      // Invalid file path information was given
      xil_printf("ERROR: Bitmap could not be opened, file path parameter was invalid\n\r");
   }
   // Try to open the bitmap file
   else if (f_open(&m_FileHandle, p_FilePath, FA_READ) != FR_OK)
   {
	   // the given file path could not be read
	   xil_printf("ERROR: %s is not a valid Bitmap-file\n\r", m_FilePath);
   }
   else if ((m_FileSize = file_size(&m_FileHandle)) >= c_BMP_MAXSIZE)
   {
	   // File size is too large
	   xil_printf("ERROR: %s is too large to be read, increase the maximal allowed bitmap size.\n\r", m_FilePath);
   }
   else if (f_read(&m_FileHandle, static_cast<void*>(m_FileContent), m_FileSize, &m_BytesRead) != FR_OK)
   {
	   // File contents could not be read
	   xil_printf("ERROR: %s File contents could not be read.\n\r", m_FilePath);
   }
   else if (m_FileSize != m_BytesRead)
   {
	   // File could not be read completely
	   xil_printf("ERROR: %s File could not be read complete.\n\r", m_FilePath);
   }
   // Try to read the bitmap header informations
   else if (loadHeader() == false)
   {
      // Bitmap header information read error
      xil_printf("ERROR: Unable to read bitmap header information from: %s\n\r", m_FilePath);
   }
   // Check for unsupported file headers
   else if (m_BmpFileHeader.bfType[0] != 'B' || m_BmpFileHeader.bfType[1] != 'M')
   {
      // Unsupported bitmap file type
      // Only windows format is supported by the decoder
      xil_printf("ERROR: Unable to read bitmap %s, bitmap is using unsupported file header format.\n\r", m_FilePath);
   }
   // Check if the used Bitmap BitCount is supported
   // Currently only a default bitmap implementation is supported, which is 24 bits per Pixel
   else if (m_BmpInfoHeader.biBitCount != c_BMP_SUPPORT_DEPTH)
   {
      // Unsupported bitmap color depth
      xil_printf("ERROR: Unable to read bitmap %s, bitmap is using the color depth %d which not supported by the decoder.\n\r", m_FilePath, m_BmpInfoHeader.biBitCount);
   }
   // Check for old bitmap format with multiple planes
   // The decoder does not support this yet
   else if (m_BmpInfoHeader.biPlanes != 1)
   {
      // A multiple plane bitmap is not supported
      xil_printf("ERROR: Unable to read bitmap %s, bitmap is using multiple color planes which is not supported by the decoder.\n\r", m_FilePath);
   }
   // Check for active data compression
   // The decoder does not support this yet
   else if (m_BmpInfoHeader.biCompression != BI_RGB)
   {
      // Data compression is not supported
      xil_printf("ERROR: Unable to read bitmap %s, bitmap is using data compression which is not supported by the decoder.\n\r", m_FilePath);
   }
   // Check for inverted Row order of pixel data
   // The pixel rows of the bitmap might be written down in inverted order
   // This is indicated by a negative bitmap height
   else if (m_BmpInfoHeader.biHeight < 0)
   {
      // Bitmap pixel data is written in inverted order which is not supported
      xil_printf("ERROR: Unable to read bitmap %s, bitmap pixel rows are written down in inverted order which is not supported by the decoder.\n\r", m_FilePath);
   }
   else
   {
      // Bitmap has been successfully loaded, print out some informations about it
      xil_printf("INFO: Bitmap loaded: %s\r\n", m_FilePath);
      xil_printf("INFO: Bitmap File size:    %d byte\r\n", m_FileSize);
      xil_printf("INFO: Bitmap Image width:  %d pixels\r\n", m_BmpInfoHeader.biWidth);
      xil_printf("INFO: Bitmap Image height: %d pixels\r\n", m_BmpInfoHeader.biHeight);
      m_Initialized = true;
   }


   return m_Initialized;
}

int BitmapImage::getSize()
{
   if (m_Initialized)
   {
      return m_FileSize;
   }
   return 0;
}

const char* BitmapImage::getFilepath()
{
   return m_FilePath;
}

void BitmapImage::extractPixelBlock(unsigned int p_GlobalRow, unsigned int p_GlobalColumn, unsigned char p_Pixelmatrix[c_MATRIX_SIZE][c_MATRIX_SIZE][c_COLOR_AMOUNT])
{
   // Data amount of a whole bitmap pixel row
   unsigned int l_BitmapRowLength = m_BmpInfoHeader.biWidth * c_COLOR_AMOUNT + (m_Padding * c_COLOR_AMOUNT);

   // Data amount of the output matrix pixel row
   unsigned int l_OutputRowLength = c_MATRIX_SIZE * c_COLOR_AMOUNT;

   // Offset for the requested matrix pixel block column
   unsigned int l_ColumnOffset = p_GlobalColumn * l_OutputRowLength;

   // Start Offset of the requested matrix pixel block inside the bitmap image
   unsigned int l_PixelBlockStartOffset = m_FileSize - l_BitmapRowLength - (l_BitmapRowLength * (p_GlobalRow * c_MATRIX_SIZE)) + l_ColumnOffset;

   // Check if the requested pixel data is out of range
   // This can happen if the width of the bitmap can not be divided through the matrix block size
   unsigned int l_MissingColumns = c_MATRIX_SIZE;
   unsigned int l_MissingPixels = 0;
   unsigned int l_MissingRows = c_MATRIX_SIZE;
   if (l_ColumnOffset + l_OutputRowLength > l_BitmapRowLength)
   {
      l_MissingPixels = (l_ColumnOffset + l_OutputRowLength - l_BitmapRowLength);
      l_MissingColumns = c_MATRIX_SIZE - (l_MissingPixels / c_COLOR_AMOUNT);
   }
   // Also check if the height of the image is big enough
   if (((p_GlobalRow + 1) * c_MATRIX_SIZE) > (unsigned long) m_BmpInfoHeader.biHeight)
   {
      l_MissingRows = c_MATRIX_SIZE - (((p_GlobalRow + 1) * c_MATRIX_SIZE) - m_BmpInfoHeader.biHeight);
   }

   // Extract the data of the 8x8 matrix row by row
   // Beware the the default bitmap is saved in reversed scan line order
   unsigned int l_UseRow = 0;
   for (unsigned int l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++)
   {
      l_UseRow = l_Row;
      // Check for missing rows, in this case we will just reuse the data of the last available row
      if (l_Row >= l_MissingRows) l_UseRow = l_MissingRows - 1;

      // Calculate the offset for each row inside the matrix block
      unsigned int l_MatrixRowOffset = l_PixelBlockStartOffset - l_UseRow * l_BitmapRowLength;

      // Extract the pixel values of the current row from the loaded bitmap data content
      unsigned int l_CopyAmount = l_OutputRowLength - l_MissingPixels;
      memcpy(p_Pixelmatrix[l_Row], m_FileContent + l_MatrixRowOffset, l_CopyAmount);

      // Fill up missing column pixels by repeating the last column pixel value
      for (unsigned int l_Column = l_MissingColumns; l_Column < c_MATRIX_SIZE; l_Column++)
      {
         for (unsigned int l_ColorIndex = 0; l_ColorIndex < c_COLOR_AMOUNT; l_ColorIndex++)
         {
            p_Pixelmatrix[l_Row][l_Column][l_ColorIndex] = p_Pixelmatrix[l_Row][l_MissingColumns - 1][l_ColorIndex];
         }
      }
   }
}

BITMAP_FILE_HEADER* BitmapImage::getFileHeader()
{
   if (m_Initialized)
   {
      return &m_BmpFileHeader;
   }
   return NULL;
}

BITMAP_INFO_HEADER* BitmapImage::getInfoHeader()
{
   if (m_Initialized)
   {
      return &m_BmpInfoHeader;
   }
   return NULL;
}

bool BitmapImage::loadHeader()
{
   bool l_Created = false;
   xil_printf("INFO: Loading Bitmap Header informations.\r\n");

   // Extract the bitmap file header data
   int l_HeaderSize = sizeof(BITMAP_FILE_HEADER) - 2;
   memcpy(&m_BmpFileHeader, m_FileContent, l_HeaderSize);

   // Extract the bitmap info header data
   int l_HeaderInfoSize = sizeof(BITMAP_INFO_HEADER);
   memcpy(&m_BmpInfoHeader, m_FileContent + l_HeaderSize, l_HeaderInfoSize);

#if 0
   // Decode the byte values into the correct format
   m_BmpFileHeader.bfSize = htonl(m_BmpFileHeader.bfSize);
   m_BmpFileHeader.bfReserved = htonl(m_BmpFileHeader.bfReserved);
   m_BmpFileHeader.bfOffBits = htonl(m_BmpFileHeader.bfOffBits);

   m_BmpInfoHeader.biSize = htonl(m_BmpInfoHeader.biSize);
   m_BmpInfoHeader.biWidth = htonl(m_BmpInfoHeader.biWidth);
   m_BmpInfoHeader.biHeight = htonl(m_BmpInfoHeader.biHeight);
   m_BmpInfoHeader.biPlanes = hton(m_BmpInfoHeader.biPlanes);
   m_BmpInfoHeader.biBitCount = hton(m_BmpInfoHeader.biBitCount);
   m_BmpInfoHeader.biCompression = htonl(m_BmpInfoHeader.biCompression);
   m_BmpInfoHeader.biSizeImage = htonl(m_BmpInfoHeader.biSizeImage);
   m_BmpInfoHeader.biXPelsPerMeter = htonl(m_BmpInfoHeader.biXPelsPerMeter);
   m_BmpInfoHeader.biYPelsPerMeter = htonl(m_BmpInfoHeader.biYPelsPerMeter);
   m_BmpInfoHeader.biClrUsed = htonl(m_BmpInfoHeader.biClrUsed);
   m_BmpInfoHeader.biClrImportant = htonl(m_BmpInfoHeader.biClrImportant);
#endif

   // Calculate the padding byte amount for each pixel row
   // But Check if a padding is really required for this image
   m_Padding = 0;
   int l_Pitch = m_BmpInfoHeader.biWidth * c_COLOR_AMOUNT; // 3 since it's 24 bits, or 3 bytes per pixel
   if (l_Pitch % 4 != 0)
   {
      m_Padding = (4 - (m_BmpInfoHeader.biWidth % 4));
   }

   // Save the file header size
   m_FileHeaderSize = l_HeaderSize + l_HeaderInfoSize;
   l_Created = true;

   return l_Created;
}

unsigned long BitmapImage::htonl(unsigned long x)
{
   // Hex long value to real long value
   return ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >> 8) | (((x) & 0x0000ff00) << 8) | (((x) & 0x000000ff) << 24));
}

unsigned short BitmapImage::hton(unsigned short x)
{
   // Hex short value to real short value
   return ((((x) & 0xff00) >> 8) | (((x) & 0x00ff) << 8));
}
