/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#include "..\Headers\CoreHuffmanEncoder.h"

/** The following array's contain are calculated Huffman code and size tables
 *  They are being generated from the Huffman Tables of the JPEG Header, in this case its the standard JPEG definition
 */
// DC Luminance Code Table
static unsigned short s_DCLuminanceCode[12];
// DC Luminance Size Table
static unsigned short s_DCLuminanceSize[12];
// DC Chrominance Code Table
static unsigned short s_DCChrominanceCode[12];
// DC Chrominance Size Table
static unsigned short s_DCChrominanceSize[12];
// AC Luminance Code Table
static unsigned short s_ACLuminanceCode[255];
// AC Luminance Size Table
static unsigned short s_ACLuminanceSize[255];
// AC Chrominance Code Table
static unsigned short s_ACChrominanceCode[255];
// AC Chrominance Size Table
static unsigned short s_ACChrominanceSize[255];
// Identifier signalizes if the tables have been initialized before
static bool s_Initialized = false;

// Array containing the last encoded value for each color
static short s_DcValue[c_COLOR_AMOUNT];
// Number of bytes available in the encoding buffer
static int s_TransferBufferLength;
// Size of the buffer containing the encoding results
static const int c_TRANSFERBUFFERSIZE = 400;
// Internal Buffer for encoding result, increases the performance
// This is useful to make it possible to writing more data into the JPEG image.
// Since the file writing byte per byte is not efficient.
static char s_TransferBuffer[c_TRANSFERBUFFERSIZE];
// Encoding buffers
static int s_VlcRemaining;
static int s_VlcAmountRemaining;


void CoreHuffmanEncoder::reset()
{
   // Check if encoder is not already set up
   s_TransferBufferLength = 0;
   s_VlcRemaining = 0x00;
   s_VlcAmountRemaining = 0x00;
   for ( short l_Index = 0; l_Index < c_COLOR_AMOUNT; l_Index++ ) s_DcValue[l_Index] = 0x00;
   for ( short l_Index = 0; l_Index < c_TRANSFERBUFFERSIZE; l_Index++ ) s_TransferBuffer[l_Index] = 0x00;
   initialze();
}

int CoreHuffmanEncoder::getEncodedDataLength()
{
   int l_Result = s_TransferBufferLength;
   s_TransferBufferLength = 0;
   return l_Result;
}

char* CoreHuffmanEncoder::getEncodedData()
{
   return s_TransferBuffer;
}

bool CoreHuffmanEncoder::finish()
{
   bool l_Finished = false;

   // Check if encoder is not already set up
   if ( s_Initialized )
   {
      // Check if there are still some bits left to send at the end of the 8x8 matrix (or maybe the file),
      // the remaining bits are filled up with ones and send
      // possible fault: -must it be filled up with ones?
      int l_PutBuffer = s_VlcRemaining;
      int l_PutBits = s_VlcAmountRemaining;

      // Add the remaining bits to output buffer
      while ( l_PutBits >= 8 )
      {
         // shift so that first byte is ready to send
         int l_PixelValue = ( l_PutBuffer >> 16 ) & 0xFF;
         addPixelValueToSendBuffer( l_PixelValue );

         // lower the value to the amount of bits that still needs to be send
         l_PutBuffer <<= 8;
         l_PutBits -= 8;
      }

      if ( l_PutBits > 0 ) // there is a last byte to send
      {
         //shift the last bits to send to the front of the byte
         int l_PixelValue = ( l_PutBuffer >> 16 ) & 0xFF;
         addPixelValueToSendBuffer( l_PixelValue );
      }

      // Clear the buffer
      s_VlcRemaining = 0x00;
      s_VlcAmountRemaining = 0x00;

      l_Finished = true;
   }
   return l_Finished;
}

bool CoreHuffmanEncoder::encode( short p_PixelValues[c_NUMBER_OF_PIXELS], unsigned short p_Color )
{
   bool l_Encoded = false;

   // Check if encoder was initialized
   if ( s_Initialized )
   {
      // Determinate code and bit size
      short l_Difference = p_PixelValues[0] - s_DcValue[p_Color];
      short l_Code = determinateCode( l_Difference );
      short l_BitSize = determinateBitSize( l_Difference );

      // Encode first pixel value -> the DC portion
      if ( l_BitSize > 11 ) l_BitSize = 11;
      if ( p_Color == 0 ) WriteCode( s_DCLuminanceCode[l_BitSize], s_DCLuminanceSize[l_BitSize] );
      else WriteCode( s_DCChrominanceCode[l_BitSize], s_DCChrominanceSize[l_BitSize] );
      if ( l_BitSize != 0 ) WriteCode( l_Code, l_BitSize );

      // Encode the other pixel values -> the AC portion
      short l_ZeroRuns = 0;
      for ( short l_Index = 1; l_Index < c_NUMBER_OF_PIXELS; l_Index++ )
      {
         // Check if pixel value is zero
         if ( p_PixelValues[l_Index] != 0 )
         {
            // Encode the zero pixel values, if any were found
            while ( l_ZeroRuns >= 16 )
            {
               // Translate magnitude into needed data (from table) and send it
               if ( p_Color == 0 ) WriteCode( s_ACLuminanceCode[0xF0], s_ACLuminanceSize[0xF0] );
               else WriteCode( s_ACChrominanceCode[0xF0], s_ACChrominanceSize[0xF0] );
               l_ZeroRuns = l_ZeroRuns - 16;
            }
            l_Code = determinateCode( p_PixelValues[l_Index] );
            l_BitSize = determinateBitSize( p_PixelValues[l_Index] );

            // Encode errors in the pixel matrix structure if required
            // There should not be any not encoded value here anymore
            short l_Error = ( l_ZeroRuns << 4 ) + l_BitSize; // <<4 -> *16
            // Translate magnitude into needed data (from table) and send it
            if ( p_Color == 0 ) WriteCode( s_ACLuminanceCode[l_Error], s_ACLuminanceSize[l_Error] );
            else WriteCode( s_ACChrominanceCode[l_Error], s_ACChrominanceSize[l_Error] );

            // Encode the magnitude of the current pixel value
            WriteCode( l_Code, l_BitSize );
            l_ZeroRuns = 0;
         }
         else
         {
            // A Zero pixel value was found increase the counter
            l_ZeroRuns = l_ZeroRuns + 1;
         }
      }
      // Encode outstanding zero values
      if ( l_ZeroRuns > 0 )
      {
         // Translate magnitude into needed data (from table) and send it
         if ( p_Color == 0 ) WriteCode( s_ACLuminanceCode[0x00], s_ACLuminanceSize[0x00] );
         else WriteCode( s_ACChrominanceCode[0x00], s_ACChrominanceSize[0x00] );
      }

      // Save the last used main DC value
      s_DcValue[p_Color] = p_PixelValues[0];
      l_Encoded = true;
   }

   return l_Encoded;
}

short CoreHuffmanEncoder::determinateCode( short p_DcDifference )
{
   // Reverse the given DC Pixel difference value if required
   // This will make sue that the revered value is positive
   short l_ReversedDcDifference = p_DcDifference;
   if ( p_DcDifference < 0 )
   {
      l_ReversedDcDifference--;
   }

   return l_ReversedDcDifference;
}

short CoreHuffmanEncoder::determinateBitSize( short p_DcDifference )
{
   // Determinate the bit amount/magnitude of the given DC difference
   short l_DcDifference = p_DcDifference < 0 ? -p_DcDifference : p_DcDifference;
   short l_Count = 0;
   while ( l_DcDifference != 0 )
   {
      l_Count++;
      l_DcDifference >>= 1;
   }
   return l_Count;
}

void CoreHuffmanEncoder::WriteCode( int p_Code, unsigned int p_BitSize )
{
   int l_PutBuffer = p_Code;
   int l_PutBits = s_VlcAmountRemaining;

   l_PutBits += p_BitSize;
   l_PutBuffer &= ( 1 << p_BitSize ) - 1;
   l_PutBuffer <<= 24 - l_PutBits;
   l_PutBuffer |= s_VlcRemaining;

   while ( l_PutBits >= 8 )
   {
      int l_Value = ( ( l_PutBuffer >> 16 ) & 0xFF );
      addPixelValueToSendBuffer( l_Value );
      l_PutBuffer <<= 8;
      l_PutBits -= 8;
   }
   s_VlcRemaining = l_PutBuffer;
   s_VlcAmountRemaining = l_PutBits;
}

void CoreHuffmanEncoder::initialze()
{
   // Initialize the Huffman code and size tables if required
   if ( s_Initialized == false )
   {
      // --------------------------------------------------
      // Initialize of the DC values for the chrominance
      // Set Huffman Size Table
      short l_HuffmanSize[257];
      short l_HuffmanCode[257];
      short l_LastHuffSize = 0;
      short l_SizeIndex = 0;
      short l_Code = 0;
      short l_Size = 0;
      for ( short l_Index = 0; l_Index < 257; l_Index++ ) l_HuffmanSize[l_Index] = 0x00;
      for ( short l_Index = 0; l_Index < 257; l_Index++ ) l_HuffmanCode[l_Index] = 0x00;
      for ( short l_Index = 0; l_Index < 16; l_Index++ )
      {
         for ( short l_Value = 1; l_Value <= c_DCChrominanceMap[l_Index]; l_Value++ )
         {
            l_HuffmanSize[l_SizeIndex++] = l_Index + 1;
         }
      }
      l_HuffmanSize[l_SizeIndex] = 0;
      l_LastHuffSize = l_SizeIndex;
      // Set Huffman Code Table
      l_Code = 0;
      l_Size = l_HuffmanSize[0];
      l_SizeIndex = 0;
      while ( l_HuffmanSize[l_SizeIndex] != 0 )
      {
         while ( l_HuffmanSize[l_SizeIndex] == l_Size )
         {
            l_HuffmanCode[l_SizeIndex++] = l_Code;
            l_Code++;
         }
         l_Code <<= 1;
         l_Size++;
      }
      // Set Huffman DC Chrominance Size and Code values
      for ( l_SizeIndex = 0; l_SizeIndex < l_LastHuffSize; l_SizeIndex++ )
      {
         s_DCChrominanceCode[c_StandardDCChrominanceHuffmanTable[l_SizeIndex]] = l_HuffmanCode[l_SizeIndex];
         s_DCChrominanceSize[c_StandardDCChrominanceHuffmanTable[l_SizeIndex]] = l_HuffmanSize[l_SizeIndex];
      }
      // --------------------------------------------------


      // --------------------------------------------------
      // Initialize of the AC values for the Chrominance
      // Set Huffman Size Table
      l_SizeIndex = 0;
      for ( short l_Index = 0; l_Index < 16; l_Index++ )
      {
         for ( short l_Value = 1; l_Value <= c_ACChrominanceMap[l_Index]; l_Value++ )
         {
            l_HuffmanSize[l_SizeIndex++] = l_Index + 1;
         }
      }
      l_HuffmanSize[l_SizeIndex] = 0;
      l_LastHuffSize = l_SizeIndex;
      // Set Huffman Code Table
      l_Code = 0;
      l_Size = l_HuffmanSize[0];
      l_SizeIndex = 0;
      while ( l_HuffmanSize[l_SizeIndex] != 0 )
      {
         while ( l_HuffmanSize[l_SizeIndex] == l_Size )
         {
            l_HuffmanCode[l_SizeIndex++] = l_Code;
            l_Code++;
         }
         l_Code <<= 1;
         l_Size++;
      }
      // Set Huffman AC Chrominance Size and Code values
      for ( l_SizeIndex = 0; l_SizeIndex < l_LastHuffSize; l_SizeIndex++ )
      {
         s_ACChrominanceCode[c_StandardACChrominanceHuffmanTable[l_SizeIndex]] = l_HuffmanCode[l_SizeIndex];
         s_ACChrominanceSize[c_StandardACChrominanceHuffmanTable[l_SizeIndex]] = l_HuffmanSize[l_SizeIndex];
      }
      // --------------------------------------------------

      // --------------------------------------------------
      // Initialize of the DC values for the Luminance
      // Set Huffman Size Table
      l_SizeIndex = 0;
      for ( short l_Index = 0; l_Index < 16; l_Index++ )
      {
         for ( short l_Value = 1; l_Value <= c_DCLuminanceMap[l_Index]; l_Value++ )
         {
            l_HuffmanSize[l_SizeIndex++] = l_Index + 1;
         }
      }
      l_HuffmanSize[l_SizeIndex] = 0;
      l_LastHuffSize = l_SizeIndex;
      // Set Huffman Code Table
      l_Code = 0;
      l_Size = l_HuffmanSize[0];
      l_SizeIndex = 0;
      while ( l_HuffmanSize[l_SizeIndex] != 0 )
      {
         while ( l_HuffmanSize[l_SizeIndex] == l_Size )
         {
            l_HuffmanCode[l_SizeIndex++] = l_Code;
            l_Code++;
         }
         l_Code <<= 1;
         l_Size++;
      }
      // Set Huffman DC Luminance Size and Code values
      for ( l_SizeIndex = 0; l_SizeIndex < l_LastHuffSize; l_SizeIndex++ )
      {
         s_DCLuminanceCode[c_StandardDCLuminanceHuffmanTable[l_SizeIndex]] = l_HuffmanCode[l_SizeIndex];
         s_DCLuminanceSize[c_StandardDCLuminanceHuffmanTable[l_SizeIndex]] = l_HuffmanSize[l_SizeIndex];
      }
      // --------------------------------------------------


      // --------------------------------------------------
      // Initialize of the AC values for the Luminance
      // Set Huffman Size Table
      l_SizeIndex = 0;
      for ( short l_Index = 0; l_Index < 16; l_Index++ )
      {
         for ( short l_Value = 1; l_Value <= c_ACLuminanceMap[l_Index]; l_Value++ )
         {
            l_HuffmanSize[l_SizeIndex++] = l_Index + 1;
         }
      }
      l_HuffmanSize[l_SizeIndex] = 0;
      l_LastHuffSize = l_SizeIndex;
      // Set Huffman Code Table
      l_Code = 0;
      l_Size = l_HuffmanSize[0];
      l_SizeIndex = 0;
      while ( l_HuffmanSize[l_SizeIndex] != 0 )
      {
         while ( l_HuffmanSize[l_SizeIndex] == l_Size )
         {
            l_HuffmanCode[l_SizeIndex++] = l_Code;
            l_Code++;
         }
         l_Code <<= 1;
         l_Size++;
      }
      // Set Huffman AC Luminance Size and Code values
      for ( l_SizeIndex = 0; l_SizeIndex < l_LastHuffSize; l_SizeIndex++ )
      {
         s_ACLuminanceCode[c_StandardACLuminanceHuffmanTable[l_SizeIndex]] = l_HuffmanCode[l_SizeIndex];
         s_ACLuminanceSize[c_StandardACLuminanceHuffmanTable[l_SizeIndex]] = l_HuffmanSize[l_SizeIndex];
      }

      s_Initialized = true;
   }
}

void CoreHuffmanEncoder::addPixelValueToSendBuffer( short p_PixelValue )
{
   if ( s_TransferBufferLength < c_TRANSFERBUFFERSIZE )
   {
      s_TransferBuffer[s_TransferBufferLength] = p_PixelValue;
      s_TransferBufferLength++;
      // In case of 0xFF a zero byte must be inserted, or this would be a invalid JPEG Header marked
      if ( p_PixelValue == 0xFF )
      {
         addPixelValueToSendBuffer( 0x00 );
      }
   }
   else
   {
      // Transfer buffer size not big enough!!!
      // Should not occur!!!
      s_TransferBufferLength = 0;
   }
}

