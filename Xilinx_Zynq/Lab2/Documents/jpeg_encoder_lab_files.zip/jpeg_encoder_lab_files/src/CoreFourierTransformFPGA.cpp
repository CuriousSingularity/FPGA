#include "..\Headers\CoreFourierTransformFPGA.h"
#include "DCT_2D_IP.h"
#include "xparameters.h"
#include <stdint.h>

#define CTRL_REG_OUT_ADDRESS				(XPAR_DCT_2D_IP_0_S00_AXI_BASEADDR + DCT_2D_IP_S00_AXI_SLV_REG48_OFFSET) // slv_reg48 added manually (ctrl_reg_out)
#define CTRL_REG_IN_ADDRESS					(XPAR_DCT_2D_IP_0_S00_AXI_BASEADDR + DCT_2D_IP_S00_AXI_SLV_REG49_OFFSET) // slv_reg49 added manually

void CoreFourierTransformFPGA::discreteCosinesTransformation( short p_Pixels[c_MATRIX_SIZE][c_MATRIX_SIZE], float p_DctResult[c_MATRIX_SIZE][c_MATRIX_SIZE] )
{
	uint8_t ubRow = 0;
	uint8_t ubCol = 0;
	int8_t *ulWriteAddress =  (int8_t*)XPAR_DCT_2D_IP_0_S00_AXI_BASEADDR;
	int16_t *ulReadAddress =  (int16_t*)(XPAR_DCT_2D_IP_0_S00_AXI_BASEADDR + DCT_2D_IP_S00_AXI_SLV_REG16_OFFSET);		// read address begin at the register slv_reg16
	uint32_t *ulCtrlRegOutAddress = (uint32_t*)(CTRL_REG_OUT_ADDRESS);
	uint32_t *ulCtrlRegInAddress = (uint32_t*)(CTRL_REG_IN_ADDRESS);

	/* write p_Pixels matrix to AXI Bus */
	for (ubRow = 0; ubRow < c_MATRIX_SIZE; ubRow++) {
		for (ubCol = 0; ubCol < c_MATRIX_SIZE; ubCol++) {
			*(ulWriteAddress) = (int8_t) p_Pixels[ubRow][ubCol];
			ulWriteAddress += 1;
		}
	}

	/* set enable and start signal */
	*(ulCtrlRegInAddress) = 3; //0b10;

	/* check if the calculation is done */
	while(1 ){
		if ((*ulCtrlRegOutAddress) & 0x1)
			break;
	}

	/* read AXI registers and store the DCT result in p_DctResult */

	for (ubRow = 0; ubRow < c_MATRIX_SIZE; ubRow++) {
		for (ubCol = 0; ubCol < c_MATRIX_SIZE; ubCol++) {
			p_DctResult[ubRow][ubCol]  = 4 * float(*ulReadAddress) ;
			ulReadAddress += 1;
		}
	}

	/* clear the start and enable flag */
	*(ulCtrlRegInAddress) = 0x0;
	(*ulCtrlRegOutAddress) = 0;

	return;
}

