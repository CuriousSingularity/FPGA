/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#include "..\Headers\CoreColorConversion.h"

void CoreColorConversion::convertRGB2YCbCr( unsigned char p_RgbPixelMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE][c_COLOR_AMOUNT],
      short p_YMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE], short p_CbMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE], short p_CrMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE] )
{
   // Temporal variables to store the color values extracted from the given pixel matrix
   unsigned char l_Red = 0;
   unsigned char l_Green = 0;
   unsigned char l_Blue = 0;
   unsigned char l_Row = 0;
   unsigned char l_Column = 0;

   // Extract Y00 Matrix values
   for ( l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++ )
   {
      for ( l_Column = 0; l_Column < c_MATRIX_SIZE; l_Column++ )
      {
         // Extract the RGB pixel values (Beware that BMP is saved in little endian -> reverse order)
         l_Red = p_RgbPixelMatrix[l_Row][l_Column][2];
         l_Green = p_RgbPixelMatrix[l_Row][l_Column][1];
         l_Blue = p_RgbPixelMatrix[l_Row][l_Column][0];

         // Convert and set the Y'CbCr Matrix values
         convertRGB2YCBCR( l_Red, l_Green, l_Blue, &p_YMatrix[l_Row][l_Column], &p_CbMatrix[l_Row][l_Column], &p_CrMatrix[l_Row][l_Column] );
      }
   }
}

void CoreColorConversion::convertRGB2YCBCR( unsigned char p_Red, unsigned char p_Green, unsigned char p_Blue, short *p_Y, short *p_CB, short *p_CR )
{
   // Extract the luminant, red-difference and blue-difference from the given RGB value using ITU-R recommendation BT.601.
   // See wikipedia for further informations about the pre defined values.

   // Summed to 65536 ( 1 << 16 ), so Y is always within [0, 255]
   // Integer based conversion busts the performance of the color conversion
   //Y[y][x] = (float)((0.299 * (float)r + 0.587 * (float)g + 0.114 * (float)b));
   //Cb1[y][x] = 128 + (float)((-0.16874 * (float)r - 0.33126 * (float)g + 0.5 * (float)b));
   //Cr1[y][x] = 128 + (float)((0.5 * (float)r - 0.41869 * (float)g - 0.08131 * (float)b)
   ( *p_Y ) = (short) ( ( 19595 * p_Red + 38470 * p_Green + 7471 * p_Blue ) >> 16 );
   ( *p_CB ) = (short) 128 + ( ( -11059 * p_Red - 21709 * p_Green + 32768 * p_Blue ) >> 16 );
   ( *p_CR ) = (short) 128 + ( ( 32768 * p_Red - 27439 * p_Green - 5329 * p_Blue ) >> 16 );

}

