/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
// Xilinx System includes
#include <stdlib.h>
#include <string.h>
#include "xparameters.h"
#include "xil_printf.h"
#include "ff.h"
#include "xtime_l.h"
// Application related includes
#include "../Headers/GlobalSettings.h"
#include "../Headers/CoreHuffmanEncoder.h"
#include "../headers/JpegImage.h"
#include "../headers\CoreMatrixConversion.h"
JpegImage::JpegImage(const char *p_FilePath, int p_BitsPerPixel, int p_Height, int p_Width)
{
   // Initialize class member variables
   this->m_Initialized = false;
   this->m_FilePath = p_FilePath;
   this->m_JpegHeaderSize = 0;
   this->m_JpegHeader = NULL;
   this->m_JpegBits = p_BitsPerPixel;
   this->m_JpegHeight = p_Height;
   this->m_JpegWidth = p_Width;
   this->m_JpegSize = 0;

   memset(&m_FileHandle, 0x0, sizeof(m_FileHandle));
}

JpegImage::~JpegImage()
{
   // Reset class variables
   this->m_Initialized = false;
   this->m_FilePath = NULL;
   this->m_JpegHeaderSize = 0;

   f_close(&m_FileHandle);

   if (this->m_JpegHeader != NULL)
   {
      free(this->m_JpegHeader);
      m_JpegHeader = NULL;
   }
   this->m_JpegSize = 0;
   this->m_JpegBits = 0;
   this->m_JpegHeight = 0;
   this->m_JpegWidth = 0;
}

bool JpegImage::initialize(int p_Quality)
{
	unsigned int bytesWritten;
	xil_printf("INFO: Initializing JPEG image. \r\n");

   // Check if JPEG file was not already loaded
   if (this->m_Initialized == true)
   {
      // JPEG already loaded
      xil_printf("ERROR: %s has already been created.\n\r", this->m_FilePath);
   }
   // Check for invalid path's
   else if (this->m_FilePath == NULL || strlen(this->m_FilePath) <= 0)
   {
      // Invalid file path information was given
      xil_printf("ERROR: JPEG could not be created, file path parameter was invalid");
   }
   else if (f_open(&m_FileHandle, m_FilePath, FA_CREATE_ALWAYS | FA_WRITE))
   {
	   // Unable to create JPEG file
	   xil_printf("ERROR: %s could not be created.\n\r", this->m_FilePath);
   }
   else if ((this->m_JpegHeaderSize = createHeader(p_Quality)) <= 0)
   {
      // Unable to create JPEG Header Informations
      xil_printf("ERROR: %s could not create JPEG Header informations.\n\r", this->m_FilePath);
   }
   else
   {
	  writeData((char*)m_JpegHeader, m_JpegHeaderSize, 0);
      xil_printf("INFO: JPEG file with header informations has been created %s .\n\r", this->m_FilePath);
      this->m_Initialized = true;
   }

   //f_sync(&m_FileHandle);
   return this->m_Initialized;
}

bool JpegImage::finish()
{
	if(FR_OK == f_close(&m_FileHandle))
		return true;
	else
		return false;
}

int JpegImage::getSize()
{
   if (m_Initialized)
   {
      // Size is: Header + Data + Footer
      return this->m_JpegHeaderSize + this->m_JpegSize + 2;
   }
   return 0;
}

void JpegImage::writeFooter()
{
	char l_Footer[2];

	l_Footer[0] = 0xff; // Comment set to ignore
	l_Footer[1] = 0xd9; // End of file identifier


	writeData(l_Footer, 2, 1);

}

int JpegImage::createHeaderSOI()
{
   // Set the Start of image marker
   this->m_JpegHeader->SOI[0] = 0xff;
   this->m_JpegHeader->SOI[1] = 0xd8;

   // Return the size of the marker
   return 2;
}

int JpegImage::createHeaderAPP()
{
   // Initialize the Application content

   // Set APP marker
   this->m_JpegHeader->APP.APP0Marker[0] = 0xff;
   this->m_JpegHeader->APP.APP0Marker[1] = 0xe0;

   // Set the APP settings
   this->m_JpegHeader->APP.Length[0] = 0x00;
   this->m_JpegHeader->APP.Length[1] = 0x10;
   this->m_JpegHeader->APP.Identifier[0] = 0x4a; // J
   this->m_JpegHeader->APP.Identifier[1] = 0x46; // F
   this->m_JpegHeader->APP.Identifier[2] = 0x49; // I
   this->m_JpegHeader->APP.Identifier[3] = 0x46; // F
   this->m_JpegHeader->APP.Identifier[4] = 0x00; //
   this->m_JpegHeader->APP.Version[0] = 0x01; // Version 1.0
   this->m_JpegHeader->APP.Version[1] = 0x00;
   this->m_JpegHeader->APP.Units = 0x00; // No units, aspect ratio only specified
   this->m_JpegHeader->APP.XDensity[0] = 0x00;
   this->m_JpegHeader->APP.XDensity[1] = 0x00;
   this->m_JpegHeader->APP.YDensity[0] = 0x00;
   this->m_JpegHeader->APP.YDensity[1] = 0x00;
   this->m_JpegHeader->APP.ThumbWidth = 0x00; // No thumb image
   this->m_JpegHeader->APP.ThumbHeight = 0x00;

   return 18;
}

int JpegImage::createHeaderDQT()
{
   // Initialize the Quantization Table content

   // Set DQT 1 (Quantization Table) marker
   // and write Quantization table to header
   this->m_JpegHeader->DQT.QTMarker1[0] = 0xff;
   this->m_JpegHeader->DQT.QTMarker1[1] = 0xdb;
   unsigned short l_Length = 2 + c_NUMBER_OF_PIXELS + 1;
   this->m_JpegHeader->DQT.Length1[0] = (l_Length & 0xff00) >> 8;
   this->m_JpegHeader->DQT.Length1[1] = l_Length & 0xff;
   this->m_JpegHeader->DQT.Id1 = 0x00; // ( Luminance 0x00 )
   // write Quantization table
   short l_ZickZackIndex = 0;
   for (short l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++)
   {
      for (short l_Column = 0; l_Column < c_MATRIX_SIZE; l_Column++)
      {
         this->m_JpegHeader->DQT.QTInfo1[c_ZIGZAG_MAP[l_ZickZackIndex]] = m_LuminanceQuantizationTable[l_Row][l_Column];
         l_ZickZackIndex++;
      }
   }

   // Set DQT 2 (Quantization Table) marker
   // and write Quantization table to header
   this->m_JpegHeader->DQT.QTMarker2[0] = 0xff;
   this->m_JpegHeader->DQT.QTMarker2[1] = 0xdb;
   l_Length = 2 + c_NUMBER_OF_PIXELS + 1;
   this->m_JpegHeader->DQT.Length2[0] = (l_Length & 0xff00) >> 8;
   this->m_JpegHeader->DQT.Length2[1] = l_Length & 0xff;
   this->m_JpegHeader->DQT.Id2 = 0x01; // ( Chrominance 0x01 )
   // write Quantization table
   l_ZickZackIndex = 0;
   for (short l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++)
   {
      for (short l_Column = 0; l_Column < c_MATRIX_SIZE; l_Column++)
      {
         this->m_JpegHeader->DQT.QTInfo2[c_ZIGZAG_MAP[l_ZickZackIndex]] = m_ChrominanceQuantizationTable[l_Row][l_Column];
         l_ZickZackIndex++;
      }
   }

   return 4 + l_Length * 2;
}

int JpegImage::createHeaderSOF()
{
   // Initialize the Start of Frame content

   // Set SOF (Start of Frame) marker
   this->m_JpegHeader->SOF.SOF0Marker[0] = 0xff;
   this->m_JpegHeader->SOF.SOF0Marker[1] = 0xc0;

   // Determinate the element content size
   int l_Components = 0x01;
   if (this->m_JpegBits != 8) l_Components = 0x03;
   int l_Length = 8 + 3 * l_Components;

   // Set Start of Frame settings
   this->m_JpegHeader->SOF.Length[0] = (l_Length & 0xff00) >> 8;
   this->m_JpegHeader->SOF.Length[1] = l_Length & 0xff;
   this->m_JpegHeader->SOF.DataPrecision = 0x08;
   this->m_JpegHeader->SOF.ImageHeight[0] = (this->m_JpegHeight & 0xff00) >> 8;
   this->m_JpegHeader->SOF.ImageHeight[1] = this->m_JpegHeight & 0xff;
   this->m_JpegHeader->SOF.ImageWidth[0] = (this->m_JpegWidth & 0xff00) >> 8;
   this->m_JpegHeader->SOF.ImageWidth[1] = this->m_JpegWidth & 0xff;
   this->m_JpegHeader->SOF.Components = l_Components;
   for (int l_Index = 0; l_Index < l_Components; l_Index++)
   {
      this->m_JpegHeader->SOF.ComponentInfo[l_Index][0] = l_Index + 1; // color component
      this->m_JpegHeader->SOF.ComponentInfo[l_Index][1] = 0x11; // subsampling off
      this->m_JpegHeader->SOF.ComponentInfo[l_Index][2] = (l_Index == 0) ? 0x00 : 0x01; // quantization table ID
   }

   return 2 + l_Length;
}

int JpegImage::createHeaderDHT()
{
   // Set the DC Luminance Huffman Table content
   this->m_JpegHeader->DHT.HTMarker1[0] = 0xff;
   this->m_JpegHeader->DHT.HTMarker1[1] = 0xc4;
   this->m_JpegHeader->DHT.Length1[0] = (31 & 0xff00) >> 8;
   this->m_JpegHeader->DHT.Length1[1] = 31 & 0xff;
   this->m_JpegHeader->DHT.TableId1 = 0x00; // Id for DC Luminance Table
   memcpy(this->m_JpegHeader->DHT.Map1, c_DCLuminanceMap, 16);
   memcpy(this->m_JpegHeader->DHT.CodeWords1, c_StandardDCLuminanceHuffmanTable, 12);

   // Set the AC Luminance Huffman Table content
   this->m_JpegHeader->DHT.HTMarker2[0] = 0xff;
   this->m_JpegHeader->DHT.HTMarker2[1] = 0xc4;
   this->m_JpegHeader->DHT.Length2[0] = (181 & 0xff00) >> 8;
   this->m_JpegHeader->DHT.Length2[1] = 181 & 0xff;
   this->m_JpegHeader->DHT.TableId2 = 0x10; // Id for AC Luminance Table
   memcpy(this->m_JpegHeader->DHT.Map2, c_ACLuminanceMap, 16);
   memcpy(this->m_JpegHeader->DHT.CodeWords2, c_StandardACLuminanceHuffmanTable, 162);

   // Set the DC Chrominance Huffman Table content
   this->m_JpegHeader->DHT.HTMarker3[0] = 0xff;
   this->m_JpegHeader->DHT.HTMarker3[1] = 0xc4;
   this->m_JpegHeader->DHT.Length3[0] = (31 & 0xff00) >> 8;
   this->m_JpegHeader->DHT.Length3[1] = 31 & 0xff;
   this->m_JpegHeader->DHT.TableId3 = 0x01; // Id for DC Chrominance Table
   memcpy(this->m_JpegHeader->DHT.Map3, c_DCChrominanceMap, 16);
   memcpy(this->m_JpegHeader->DHT.CodeWords3, c_StandardDCChrominanceHuffmanTable, 12);

   // Set the AC Chrominance Huffman Table content
   this->m_JpegHeader->DHT.HTMarker4[0] = 0xff;
   this->m_JpegHeader->DHT.HTMarker4[1] = 0xc4;
   this->m_JpegHeader->DHT.Length4[0] = (181 & 0xff00) >> 8;
   this->m_JpegHeader->DHT.Length4[1] = 181 & 0xff;
   this->m_JpegHeader->DHT.TableId4 = 0x11; // Id for AC Chrominance Table
   memcpy(this->m_JpegHeader->DHT.Map4, c_ACChrominanceMap, 16);
   memcpy(this->m_JpegHeader->DHT.CodeWords4, c_StandardACChrominanceHuffmanTable, 162);

   return 2 + 31 + 2 + 181 + 2 + 31 + 2 + 181;
}

void JpegImage::writeData(char *p_Chars, int p_Length, bool full)
{
	FRESULT res;
	unsigned int bytesWritten;

	static XTime l_time = 0;

	// Transfer buffer
	static char l_Transferbuffer[c_TransferbufferSize_Bytes];
	static int l_BytesInTransferbuffer = 0;
	int l_EncodedDataLen = p_Length;

	for(int i=0 ; i<l_EncodedDataLen; i++)
		l_Transferbuffer[i+l_BytesInTransferbuffer] = p_Chars[i];
	l_BytesInTransferbuffer += l_EncodedDataLen;

	if(l_BytesInTransferbuffer >= c_BytesToTransfer)
	{

/*		while(1/((double)(l_time) / COUNTS_PER_SECOND) < c_MaxSDWriteFreq_Hz)
		{
			XTime_GetTime(&l_time);
		}
		l_time = 0;
		XTime_SetTime(l_time);*/

		if(l_BytesInTransferbuffer > c_TransferbufferSize_Bytes)
			xil_printf("Error: Transferbuffer overflow!");

		if ((res = f_write(&m_FileHandle,
							(void*)(l_Transferbuffer),
							c_BytesToTransfer,
							&bytesWritten)) != FR_OK)
		{
			xil_printf("ERROR: %s could not write JPEG data.\n\r", this->m_FilePath);

		}
		else
		{
			f_sync(&m_FileHandle);
			m_JpegSize += c_BytesToTransfer;
		}

		l_BytesInTransferbuffer -= c_BytesToTransfer;
		for(int i=0; i<(l_BytesInTransferbuffer); i++)
			l_Transferbuffer[i] = l_Transferbuffer[i+c_BytesToTransfer];
	}

	if(full)
	{

/*		while(1/((double)(l_time) / COUNTS_PER_SECOND) < c_MaxSDWriteFreq_Hz)
		{
			XTime_GetTime(&l_time);
		}
		l_time = 0;
		XTime_SetTime(l_time);*/


		if ((res = f_write(&m_FileHandle,
									(void*)(l_Transferbuffer),
									l_BytesInTransferbuffer,
									&bytesWritten)) != FR_OK)
		{
			xil_printf("ERROR: %s could not write JPEG data.\n\r", this->m_FilePath);
		}
		else
		{
			m_JpegSize += l_BytesInTransferbuffer;
		}
		l_BytesInTransferbuffer = 0;
	}
}

int JpegImage::createHeaderSOS()
{
   // Initialize the Scan Header content

   // Set SOS (Scan Header) marker
   this->m_JpegHeader->SOS.SOSMarker[0] = 0xff;
   this->m_JpegHeader->SOS.SOSMarker[1] = 0xda;
   this->m_JpegHeader->SOS.Length[0] = (12 & 0xff00) >> 8;
   this->m_JpegHeader->SOS.Length[1] = 12 & 0xff;
   this->m_JpegHeader->SOS.ComponentCount = c_COLOR_AMOUNT; // number of color components in the image
   this->m_JpegHeader->SOS.Component[0][0] = 0x01; // Y component
   this->m_JpegHeader->SOS.Component[0][1] = 0x00; // indexes of huffman tables for Y-component
   this->m_JpegHeader->SOS.Component[1][0] = 0x02; // the CB component
   this->m_JpegHeader->SOS.Component[1][1] = 0x11; // indexes of huffman tables for CB-component
   this->m_JpegHeader->SOS.Component[2][0] = 0x03; // The CR component
   this->m_JpegHeader->SOS.Component[2][1] = 0x11; // indexes of huffman tables for CR-component

   // following bytes are ignored since progressive scan is not to be implemented
   this->m_JpegHeader->SOS.Ignore[0] = 0x00;
   this->m_JpegHeader->SOS.Ignore[1] = 0x00;
   this->m_JpegHeader->SOS.Ignore[2] = 0x00;

   return 2 + 12;
}

int JpegImage::createHeader(int p_Quality)
{
   xil_printf("INFO: Creating JPEG header informations. \r\n");

   if (m_JpegHeader == NULL)
   {
      // Initialize Quantization/Quality Tables
      int l_Quality = p_Quality;
      if (l_Quality <= 0) l_Quality = 1;
      else if (l_Quality > 100) l_Quality = 100;
      else if (l_Quality < 50) l_Quality = 5000 / l_Quality;
      else l_Quality = 200 - l_Quality * 2;

      // Modifiy Quantization tables by using a quality setting
      int l_Value = 0;
      for (short l_Row = 0; l_Row < c_MATRIX_SIZE; l_Row++)
      {
         for (short l_Column = 0; l_Column < c_MATRIX_SIZE; l_Column++)
         {
            l_Value = (c_DefaultLuminanceQuantizationTable[l_Row][l_Column] * l_Quality + 50) / 100;
            if (l_Value <= 0) l_Value = 1;
            else if (l_Value > 255) l_Value = 255;
            m_LuminanceQuantizationTable[l_Row][l_Column] = l_Value;
            m_LuminanceQuantizationDivisor[l_Row][l_Column] = 1.0 / (l_Value * c_QuantizationScaleFactor[l_Row] * c_QuantizationScaleFactor[l_Column] * 8.0);

            l_Value = (c_DefaultLuminanceQuantizationTable[l_Row][l_Column] * l_Quality + 50) / 100;
            if (l_Value <= 0) l_Value = 1;
            else if (l_Value > 255) l_Value = 255;
            m_ChrominanceQuantizationTable[l_Row][l_Column] = l_Value;
            m_ChrominanceQuantizationDivisor[l_Row][l_Column] = 1.0 / (l_Value * c_QuantizationScaleFactor[l_Row] * c_QuantizationScaleFactor[l_Column] * 8.0);
         }
      }

      // Create the JPEG Header Parts
      m_JpegHeader = (JPEGHEADER*) malloc(sizeof(JPEGHEADER));
      int l_Size = 0;
      l_Size += createHeaderSOI();
      l_Size += createHeaderAPP();
      l_Size += createHeaderDQT();
      l_Size += createHeaderSOF();
      l_Size += createHeaderDHT();
      l_Size += createHeaderSOS();
      return l_Size;
   }
   return this->m_JpegHeaderSize;
}
