/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
//#define TEST_MAIN

// Xilinx
#include "xil_cache.h"

// Generated
#include "../headers/platform.h"

// Application layer
#include "../headers/CEncoderFsm.h"

#include "../headers/CoreFourierTransformFPGA.h"

int main(void)
{

		JpegEncoder::CEncoderFsm encoderFsm;

		/* Init function provided by Xilinx */
		init_platform();

		/* Disable the arm data cache, else SD card will not work */
		Xil_DCacheFlush();
		Xil_DCacheDisable();

		/* Will not return */
		encoderFsm.start();

		return 0;
}
