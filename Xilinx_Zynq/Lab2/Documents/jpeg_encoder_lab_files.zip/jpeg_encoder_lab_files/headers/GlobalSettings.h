/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#ifndef GLOBALSETTINGS_H_
#define GLOBALSETTINGS_H_

   static const int c_TransferbufferSize_Bytes = 1000;
   static const int c_BytesToTransfer = 512;
 //  static const int c_MaxSDWriteFreq_Hz = 50;

   // JPEG Image quality in percantage (1-100%) this values influences the generated quantization tables
   static const unsigned short c_JPEG_QUALITY = 100;

   // JPEG Color space amount (Y' Cr Cb)
   static const unsigned short c_COLOR_AMOUNT = 3;

   // Matrix Size used for Fourier transformation calculations
   static const unsigned short c_MATRIX_SIZE = 8;

   // Number of Pixels inside a Matrix used by by the Fourier transformations
   static const unsigned short c_NUMBER_OF_PIXELS = c_MATRIX_SIZE * c_MATRIX_SIZE;

   // A maximum amount of 100 files or file system entries is currently supported
   // Increase if required
   static const unsigned short c_MAX_DIR_ENTRIES = 100;

   // File attributes
   // Have to be defined here since the required include is not working
   static const short c_ATTR_ARCHIVE = 0x20;
   static const short c_ATTR_DIRECTORY = 0x10;
   static const short c_ATTR_VOLUME_ID = 0x08;
   static const short c_ATTR_SYSTEM = 0x04;
   static const short c_ATTR_HIDDEN = 0x02;
   static const short c_ATTR_READ_ONLY = 0x01;

   /**
    * The human eye is good at seeing small differences in brightness over a relatively large area,
    * but not so good at distinguishing the exact strength of a high frequency brightness variation.
    * This allows one to greatly reduce the amount of information in the high frequency components.
    * This is done by simply dividing each component in the frequency domain by a constant for that component,
    * and then rounding to the nearest integer.
    *
    * This rounding operation is the only lossy operation in the whole process if the DCT computation is performed
    * with sufficiently high precision.
    * As a result of this, it is typically the case that many of the higher frequency components are rounded to zero,
    * and many of the rest become small positive or negative numbers, which take many fewer bits to represent.
    *
    * So by using the following Quantization matrix we remove some of this higher frequency components.
    *
    * Definition of the Frequency Components weight. (The higher the matrix value the more the frequency is removed)
    * Matrix:
    *                Low Freq. -> High Freq.
    *              1 | 2 | 3 | 4 | 5 ...
    *   Low Freq.  2 | ...
    *       |      3 | ...
    *   High Freq. 4 | ...
    *               ...
    */
   // The following values reperesent the standard JPEG quantization tables
   // By using the qualitiy attributes, these values might will be modified during runtime
   static const unsigned char c_DefaultLuminanceQuantizationTable[c_MATRIX_SIZE][c_MATRIX_SIZE] = {
         { 16, 11, 10, 16, 24, 40, 51, 61 },
         { 12, 12, 14, 19, 26, 58, 60, 55 },
         { 14, 13, 16, 24, 40, 57, 69, 56 },
         { 14, 17, 22, 29, 51, 87, 80, 62 },
         { 18, 22, 37, 56, 68, 109, 103, 77 },
         { 24, 35, 55, 64, 81, 104, 113, 92 },
         { 49, 64, 78, 87, 103, 121, 120, 101 },
         { 72, 92, 95, 98, 112, 100, 103, 99 } };
   static const unsigned char c_DefaultChrominanceQuantizationTable[c_MATRIX_SIZE][c_MATRIX_SIZE] = {
         { 17, 18, 24, 47, 99, 99, 99, 99 },
         { 18, 21, 26, 66, 99, 99, 99, 99 },
         { 24, 26, 56, 99, 99, 99, 99, 99 },
         { 47, 66, 99, 99, 99, 99, 99, 99 },
         { 99, 99, 99, 99, 99, 99, 99, 99 },
         { 99, 99, 99, 99, 99, 99, 99, 99 },
         { 99, 99, 99, 99, 99, 99, 99, 99 },
         { 99, 99, 99, 99, 99, 99, 99, 99 } };
   static const float c_QuantizationScaleFactor[c_MATRIX_SIZE]=
        {  1.0, 1.387039845, 1.306562965, 1.175875602, 1.0, 0.785694958, 0.541196100, 0.275899379};

   // The following tables are provided in the JPEG standard / specification as examples of "typical" huffman tables.
   // They were apparently generated from "the average statistics of a large set of video images with 8-bit precision".
   // Presumably, these will provide a reasonably close approximation to the compression performance of a
   // true custom-optimized table for the majority of photographic content.
   // The advantage of using these tables is that no compute-intensive second-pass analysis
   // would then be required prior to encoding into the JPEG file format.
   //
   // Mapping tables for encoding the 4 huffman table into the Jpeg file
   static const unsigned char c_DCLuminanceMap[16]   = { 0x00, 0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
   static const unsigned char c_DCChrominanceMap[16] = { 0x00, 0x03, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00 };
   static const unsigned char c_ACLuminanceMap[16]   = { 0x00, 0x02, 0x01, 0x03, 0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D };
   static const unsigned char c_ACChrominanceMap[16] = { 0x00, 0x02, 0x01, 0x02, 0x04, 0x04, 0x03, 0x04, 0x07, 0x05, 0x04, 0x04, 0x00, 0x01, 0x02, 0x77 };
   // Standard DC Luminance Huffman Table for JPEG files
   static const unsigned char c_StandardDCLuminanceHuffmanTable[12] = {
     /* 2 */   0x00,
     /* 3 */   0x01, 0x02, 0x03, 0x04, 0x05,
     /* 4 */   0x06,
     /* 5 */   0x07,
     /* 6 */   0x08,
     /* 7 */   0x09,
     /* 8 */   0x0A,
     /* 9 */   0x0B, };
   // Standard DC Chrominance Huffman Table  for JPEG files
   static const unsigned char c_StandardDCChrominanceHuffmanTable[12] = {
     /* 2 */   0x00, 0x01, 0x02,
     /* 3 */   0x03,
     /* 4 */   0x04,
     /* 5 */   0x05,
     /* 6 */   0x06,
     /* 7 */   0x07,
     /* 8 */   0x08,
     /* 9 */   0x09,
     /*10 */   0x0A,
     /*11 */   0x0B };
   // Standard AC Luminance Huffman Table for JPEG files
   static const unsigned char c_StandardACLuminanceHuffmanTable[162] = {
     /* 1 */
     /* 2 */   0x01, 0x02,
     /* 3 */   0x03,
     /* 4 */   0x00, 0x04, 0x11,
     /* 5 */   0x05, 0x12, 0x21,
     /* 6 */   0x31, 0x41,
     /* 7 */   0x06, 0x13, 0x51, 0x61,
     /* 8 */   0x07, 0x22, 0x71,
     /* 9 */   0x14, 0x32, 0x81, 0x91, 0xA1,
     /*10 */   0x08, 0x23, 0x42, 0xB1, 0xC1,
     /*11 */   0x15, 0x52, 0xD1, 0xF0,
     /*12 */   0x24, 0x33, 0x62, 0x72,
     /*13 */   0x82,
     /*14 */
     /*15 */   0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54,
               0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85,
               0x86, 0x87, 0x88, 0x89, 0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3,
               0xB4, 0xB5, 0xB6, 0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA,
               0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA };
     /*16*/
   // Standard AC Chrominance  Huffman Table for JPEG files
   static const unsigned char c_StandardACChrominanceHuffmanTable[162] = {
     /* 1 */
     /* 2 */   0x00, 0x01,
     /* 3 */   0x02,
     /* 4 */   0x03, 0x11,
     /* 5 */   0x04, 0x05, 0x21, 0x31,
     /* 6 */   0x06, 0x12, 0x41, 0x51,
     /* 7 */   0x07, 0x61, 0x71,
     /* 8 */   0x13, 0x22, 0x32, 0x81,
     /* 9 */   0x08, 0x14, 0x42, 0x91, 0xA1, 0xB1, 0xC1,
     /*10 */   0x09, 0x23, 0x33, 0x52, 0xF0,
     /*11 */   0x15, 0x62, 0x72, 0xD1,
     /*12 */   0x0A, 0x16, 0x24, 0x34,
     /*13 */
     /*14 */   0xE1,
     /*15 */   0x25, 0xF1,
     /*16 */   0x17, 0x18, 0x19, 0x1A, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43,
               0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x63,
               0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x82,
               0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99,
               0x9A, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
               0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xD2, 0xD3, 0xD4, 0xD5,
               0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF2, 0xF3,
               0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA};


   // Mapping between a ZigZag order 8x8 Matrix and a normal one
   // TODO -> initialize this table dynamically on the MATRIX_SITE constant
   static const short c_ZIGZAG_MAP[c_NUMBER_OF_PIXELS] = {
         0,  1,  5,  6,  14, 15, 27, 28,
         2,  4,  7,  13, 16, 26, 29, 42,
         3,  8,  12, 17, 25, 30, 41, 43,
         9,  11, 18, 24, 31, 40, 44, 53,
         10, 19, 23, 32, 39, 45, 52, 54,
         20, 22, 33, 38, 46, 51, 55, 60,
         21, 34, 37, 47, 50, 56, 59, 61,
         35, 36, 48, 49, 57, 58, 62, 63 };

#endif // GLOBALSETTINGS_H_
