/*
 * zzq.h
 *
 *  Created on: 20.02.2012
 *      Author: Paul
 */
#ifndef MATRIXCONVERSION_H_
#define MATRIXCONVERSION_H_

#include "..\Headers\GlobalSettings.h"

/**
 * Contains the DCT to JPEG Pixel conversion
 */
class CoreMatrixConversion
{
   public:
      /**
       * Initializes the quantizations tables by using a quality setting
       *
       *@Input DCT Pixel Matrix
       *@Output JPEG Pixel Matrix
       */
      static void initMatrix( short p_Quality );
      /**
       * Convert the DCT Pixel Matrix back to real Pixel values
       *
       *@Input DCT Pixel Matrix
       *@Output JPEG Pixel Matrix
       */
      static void quantize(float p_PixelMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE], float p_QuantizationDivisor[c_MATRIX_SIZE][c_MATRIX_SIZE],
            short p_Pixel[c_NUMBER_OF_PIXELS]  );
};
#endif /* MATRIXCONVERSION_H_ */
