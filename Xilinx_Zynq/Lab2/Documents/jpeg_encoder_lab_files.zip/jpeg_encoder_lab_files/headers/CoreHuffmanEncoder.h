/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#ifndef HUFFMANENCODING_H_
#define HUFFMANENCODING_H_

#include "..\Headers\GlobalSettings.h"

/**
 * Implementation of a huffman encoding for the Y' Cb Cr Pixel space of a JPEG image
 */
class CoreHuffmanEncoder
{
   public:
      /**
       * Resets the huffman encoder by setting up the start configuration
       */
      static void reset();
      /**
       * Encodes a given data image block by using the Huffman tables
       *
       * @p_Dataunit Y'CrCb Pixel Block
       * @p_Color Definition if Y' or Cr or Cb pixel block is encoded
       * @Output True if encoding was successful, else false
       */
      static bool encode( short p_Dataunit[c_NUMBER_OF_PIXELS], unsigned short p_Color );
      /**
       * Finishes the Huffman encoding
       * @Output True if encoding was successful, else false
       */
      static bool finish();
      /**
       *  Attention - First determinate the Encoded Data Length
       *              Because calling this method will reset the data length
       * @Output Number of bytes available in the encoding buffer
       */
      static int getEncodedDataLength();
      /**
       *  @Output Returns the current buffer containing the encoded data characters
       */
      static char* getEncodedData();

   private:
      /**
       * Initialize the huffman encoder by calculating the Huffman code and size tables
       * This will be done only once, at the beginning of the encoding
       */
      static void initialze();
      /**
       * Adds a given Pixel value to the current transfer buffer
       * and increases the buffer length
       */
      static void addPixelValueToSendBuffer( short p_PixelValue );
      /**
       * Reverts bitwise the given DC difference value (or any other value)
       * This ensures that the given value represents a positive value expression
       */
      static short determinateCode( short p_DcDifference );
      /**
       * Determinate the magnitude/byte amount of a given reversed DC difference value
       * By using this method, the algorithms detects the grade of difference
       * between the last encoded DC value and the new Pixel value
       */
      static short determinateBitSize( short p_ReversedDcDifference );
      /**
       * This function collects bits to send
       * if there less than 16 bits collected, nothing is send and these bits are stored in *remaining.
       * In *amount_remaining there is stated how much bits are stored in *remaining
       * if more than 16 bits are collected, 16 bits are send and the remaining bits are stored again
       * *remaining needs be more than 8 bits because 8 bits could be added and their could already be up to 7 bits in *remaining
       */
      static void WriteCode( int p_Code, unsigned int p_Bits );
};

#endif /* HUFFMANENCODING_H_ */
