/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#ifndef BITMAPIMAGE_H_
#define BITMAPIMAGE_H_

#include "GlobalSettings.h"

// Struct defines the file header of a bitmap file
// The order of the values represent the first bytes inside a bitmap file
typedef struct
{
      char bfType[2];     // the header field used to identify the BMP & DIB file is 0x42 0x4D in hexadecimal, same as BM in ASCII. The following entries are possible:
                           // BM � Windows 3.1x, 95, NT, ... etc.; and it is not mandatory unless file size is greater or equal to SIGNATURE
                           // BA � OS/2 struct Bitmap Array
                           // CI � OS/2 struct Color Icon
                           // CP � OS/2 constant Color Pointer
                           // IC � OS/2 struct Icon
                           // PT � OS/2 Pointer
      unsigned long bfSize;     // the size of the BMP file in bytes (unsafe)
      unsigned long bfReserved; // reserved; actual value depends on the application that creates the image
      unsigned long bfOffBits;  // the offset, i.e. starting address, of the byte where the bitmap image data (pixel array) can be found.
}BITMAP_FILE_HEADER;

// Struct defines the information header of a bitmap file
// The order of the values represent the first bytes inside a bitmap file
typedef struct
{
      unsigned long biSize;                          /* the size of this header (40 bytes)     */
      signed long  biWidth, biHeight;                /* the bitmap width, height in pixels (signed integer). */
      unsigned short biPlanes;                        /* the number of color planes being used. Must be set to 1.    */
      unsigned short biBitCount;                      /* the number of bits per pixel, which is the color depth of the image. Typical values are 1, 4, 8, 16, 24 and 32.            */
      unsigned long biCompression;                   /* the compression method being used. See the next table for a list of possible values.          */
      unsigned long biSizeImage;                     /* the image size. This is the size of the raw bitmap data (see below), and should not be confused with the file size.      */
      signed long  biXPelsPerMeter, biYPelsPerMeter; /* the horizontal, vertical resolution of the image. (pixel per meter, signed integer)          */
      unsigned long biClrUsed;                       /* the number of colors in the color palette, or 0 to default to 2n.        */
      unsigned long biClrImportant;                  /* the number of important colors used, or 0 when every color is important; generally ignored.         */
      //unsigned char palette[1024];            /* Storage for indexed color palate, size 2^biBitCount */
} BITMAP_INFO_HEADER;

// Possible bitmap data compression methods
typedef enum {
  BI_RGB = 0,
  BI_RLE8,
  BI_RLE4,
  BI_BITFIELDS, //Huffman 1D
  BI_JPEG,      //RLE-24
  BI_PNG
} BITMAP_COMPRESSION;

/**
 * Class defined the general structure of a bitmap file
 */
class BitmapImage
{
   public:
      /**
       * Destructor
       */
      static void reset();
      /**
       * Initializes the bitmap image instance by loading the data from the
       * pre defined file path
       */
      static bool initialize( const char *p_FilePath );
      /**
       * Returns the loaded Bitmap Info Header informations
       */
      static BITMAP_INFO_HEADER* getInfoHeader();
      /**
       * Returns the loaded Bitmap File Header informations
       */
      static BITMAP_FILE_HEADER* getFileHeader();
      /**
       * Returns the used bitmap file path
       */
      static const char* getFilepath();
      /**
       * Returns the loaded Bitmap Pixel values for a definition range
       *
       * @p_GlobalRow Row of the 8x8 pixel block
       * @p_GlobalColumn Column of the 8x8 pixel block
       * @p_Pixelmatrix Extracted 8x8 pixel block content (Attention - unsigned char is strictly required since the color values go from 0-255)
       */
      static void extractPixelBlock( unsigned int p_GlobalRow, unsigned int p_GlobalColumn, unsigned char p_Pixelmatrix[c_MATRIX_SIZE][c_MATRIX_SIZE][c_COLOR_AMOUNT] );
      /**
       * Returns the size of the loaded bitmap file
       */
      static int getSize();

   private:
      /**
       * Loads the bitmap header of the defined file path
       */
      static bool loadHeader();
      /**
       * Convert the hex long value from the bitmap data to a real long value
       */
      static unsigned long htonl( unsigned long x );
      /**
       * Convert the hex short value from the bitmap data to a real short value
       */
      static unsigned short hton( unsigned short x );
};

#endif /* BITMAPIMAGE_H_ */
