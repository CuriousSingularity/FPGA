/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#ifndef COREFOURIERTRANSFORMFPGA_H_
#define COREFOURIERTRANSFORMFPGA_H_

#include "..\Headers\GlobalSettings.h"



/**
 * Contains the communication with the DCT core on the FPGA
 */
class CoreFourierTransformFPGA
{
   public:

      /**
       * Discrete Cosines Transformation
       * Each 8�8 block of each component (Y', Cb, Cr) is converted to a frequency-domain representation,
       * using a normalized,
       * two-dimensional type-II discrete cosine transform (DCT)
       *
       * Input: pixels is the matrix input array
       * Output: Discrete Cosines Transformation result matrix
       */
      static void discreteCosinesTransformation( short p_Pixels[c_MATRIX_SIZE][c_MATRIX_SIZE], float p_DctResult[c_MATRIX_SIZE][c_MATRIX_SIZE] );
};
#endif /* COREFOURIERTRANSFORMFPGA_H_ */
