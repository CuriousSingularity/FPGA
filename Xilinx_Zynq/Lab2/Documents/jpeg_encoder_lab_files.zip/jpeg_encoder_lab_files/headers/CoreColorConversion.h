/*
 * Project: Bitmap to JPEG Converter
 * University of applied science Darmstadt
 *
 * Created on: 20.02.2012
 * Author: Paul Scheider
 */
#ifndef CORECOLORCONVERSION_H_
#define CORECOLORCONVERSION_H_

#include "..\Headers\GlobalSettings.h"

/**
 * Contains the color conversion routines
 * to convert RGB to to Y′CbCr space for a Bitmap macro block
 */
class CoreColorConversion
{
   public:
      //###################################
      // Main methods for color conversions
      //###################################
      /**
       * Color Conversion RGB to Y′CbCr space (CCIR 601)
       *
       * YCbCr, Y′CbCr, or Y Pb/Cb Pr/Cr, also written as YCBCR or Y′CBCR,
       * is a family of color spaces used as a part of the color image pipeline
       * in video and digital photography systems.
       * Y′ is the luma component and
       * CB and CR are the blue-difference and red-difference chroma components.
       * Y′ (with prime) is distinguished from Y which is luminance, meaning that light intensity is non-linearly encoded using gamma correction.
       *
       * A Conversion is required,
       * since Bitmap's are using the RGB color space.
       * JPEG images are using the Y′CbCr space (CCIR 601).
       *
       * @p_RgbPixelMatrix Bitmap Pixel Matrix containing the RGB values of a extracted bitmap block
       * @p_Y00Matrix Y Pixel Matrix 1 (CCIR 601)
       * @p_Y01Matrix Y Pixel Matrix 2 (CCIR 601)
       * @p_Y11Matrix Y Pixel Matrix 3 (CCIR 601)
       * @p_Y12Matrix Y Pixel Matrix 4 (CCIR 601)
       * @p_CbMatrix Cb Pixel Matrices (CCIR 601)
       * @p_CrMatrix Cr Pixel Matrices (CCIR 601)
       */
      static void convertRGB2YCbCr( unsigned char p_RgbPixelMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE][c_COLOR_AMOUNT],
            short p_Y0Matrix[c_MATRIX_SIZE][c_MATRIX_SIZE], short p_CbMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE], short p_CrMatrix[c_MATRIX_SIZE][c_MATRIX_SIZE] );

   private:
      //###################################
      // Sub methods for color conversions
      //###################################
      /**
       * Color Conversion RGB to Y′CbCr space (CCIR 601)
       * @Input RGB pixel color value
       * @Output Y' luma component
       * @Output Cr red-difference value
       * * @Output Cb blue-difference value
       */
      static void convertRGB2YCBCR( unsigned char p_Red, unsigned char p_Green, unsigned char p_Blue, short *p_Y, short *p_CB, short *p_CR );
};

#endif /* COLORCONVERSION_H_ */
