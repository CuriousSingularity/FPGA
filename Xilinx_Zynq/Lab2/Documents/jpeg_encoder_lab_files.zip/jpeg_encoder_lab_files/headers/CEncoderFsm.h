/*
 * CEncoderFsm.h
 *
 *  Created on: 07.05.2014
 *      Author: Marc Maier
 */

#ifndef CENCODERFSM_H_
#define CENCODERFSM_H_

#include "vector"
#include "iostream"
#include "string"

/* Can't be forward declared due to typedefs */

/* Timer */
#include "xtmrctr.h"
#include "xtmrctr_i.h"

/* SD card */
#include "ff.h"

/* GPIOs */
#include "xgpiops.h"
#include "xgpiops_hw.h"

class BitmapImage;
class JpegImage;

namespace JpegEncoder
{

class CEncoderFsm
{
public: /* methods */
    explicit CEncoderFsm();
    ~CEncoderFsm();

    void start();

private: /* methods */
    bool initGpio(XGpioPs *Gpio, int Pin, int Direction);
    bool startPushed();
    void collectSeconds(double *p_ModuleTime, double *p_EncodingTime);
    bool isBmp(const char *fname) const;
    bool initialize();
    std::string createJpegPath(std::string bmpPath) const;
    bool createJpeg(const char *p_JpegFilename);
    bool encode();
    XTmrCtr s_XpsTimer;

private: /* variables */
    enum states {
        ready,
        initializing,
        encoding,
    };

    enum states m_state;

    BitmapImage *m_bmpImage;
    JpegImage *m_jpegImage;

    static const char *m_bmpFolderPath;
    static const char *m_jpgFolderPath;

    std::vector<std::string> m_bmpFilePaths;

    XTmrCtr m_axiTimer;
	FATFS m_fatfs;

	XGpioPs m_Btn;
	XGpioPs m_Led;
};

} /* namespace JpegEncoder */

#endif /* CENCODERFSM_H_ */
